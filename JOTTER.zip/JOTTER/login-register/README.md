The following is a notes taking website created by me, I have used Bootstrap for frontend and JavaScript for the backend and the website is fully functional you can add notes, delete them, mark them as important or revert them to normal and search your notes from many notes by using the search bar.

This was my first JavaScript Project and I have completed it in 3 Days, I will be Learning more and more and will be making more amazing and awesome projects.

You all are free to checkout the code of the website and reach out to me if you find any bug in the code or bug in the functioning of the website.
